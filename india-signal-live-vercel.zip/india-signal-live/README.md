# India Signal Live

A mobile-friendly India-wide traffic-signal map designed around one rule:

**Never show a fake signal countdown.**

The frontend:
- India map
- GPS location
- India-only place search/autocomplete
- signal markers
- live countdown display when an authorised provider supplies phase + remaining seconds
- explicit "Live countdown unavailable" when it does not

## Deploy on Vercel

1. Put these files in a GitHub repository.
2. Import the repository into Vercel.
3. Add the environment variable `SIGNAL_FEEDS`.
4. `SIGNAL_FEEDS` must contain only authorised live signal feeds.

Example:
[
  {
    "name": "City TMC",
    "url": "https://YOUR-AUTHORISED-ENDPOINT/signals",
    "tokenEnv": "CITY_TMC_TOKEN"
  }
]

Then add `CITY_TMC_TOKEN` as another Vercel environment variable.

## Important

There is no verified public nationwide API that exposes every Indian traffic signal's live controller countdown. A nationwide app therefore needs agreements/API access from individual city Traffic Management Centres, smart-city operators, or signal-system vendors.

The architecture is ready for those feeds, but it intentionally does not simulate countdowns.
