// Vercel serverless endpoint.
// IMPORTANT: This endpoint never invents countdown values.
// Configure authorised provider feeds in SIGNAL_FEEDS as a JSON array.
// Each feed should return: { "signals": [ {id,name,city,lat,lng,live,phase,remaining_s,source} ] }
//
// Example environment variable shape:
// SIGNAL_FEEDS=[{"url":"https://authorised.example/api/signals","tokenEnv":"SIGNAL_PROVIDER_TOKEN"}]
//
// The provider must be authorised to expose live controller state.
// Static signal locations may be returned with live:false.

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  const raw = process.env.SIGNAL_FEEDS || "[]";
  let feeds = [];
  try { feeds = JSON.parse(raw); } catch (_) {}

  const out = [];
  for (const feed of feeds) {
    try {
      const headers = { "Accept": "application/json" };
      if (feed.tokenEnv && process.env[feed.tokenEnv]) {
        headers.Authorization = `Bearer ${process.env[feed.tokenEnv]}`;
      }
      const r = await fetch(feed.url, { headers });
      if (!r.ok) continue;
      const data = await r.json();
      for (const s of (data.signals || [])) {
        out.push({
          id:s.id, name:s.name, city:s.city, lat:Number(s.lat), lng:Number(s.lng),
          live:s.live === true,
          phase:s.live ? s.phase : null,
          remaining_s:s.live && Number.isFinite(Number(s.remaining_s)) ? Number(s.remaining_s) : null,
          source:s.source || feed.name || "Authorised feed"
        });
      }
    } catch (_) {}
  }

  return res.status(200).json({ updated_at:new Date().toISOString(), signals:out });
}